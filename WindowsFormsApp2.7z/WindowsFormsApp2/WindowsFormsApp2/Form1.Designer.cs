﻿namespace WindowsFormsApp2
{
    partial class Form_DisplayPicture
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox_SelectScreen = new System.Windows.Forms.ComboBox();
            this.label_SelectScreen = new System.Windows.Forms.Label();
            this.button_Exit = new System.Windows.Forms.Button();
            this.button_Browse = new System.Windows.Forms.Button();
            this.folderDialogBox = new System.Windows.Forms.FolderBrowserDialog();
            this.textBox_FileLocation = new System.Windows.Forms.TextBox();
            this.label_Location = new System.Windows.Forms.Label();
            this.label_DisplayTime = new System.Windows.Forms.Label();
            this.numericUpDown_DisplayTime = new System.Windows.Forms.NumericUpDown();
            this.button_Show = new System.Windows.Forms.Button();
            this.pictureBox_Display = new System.Windows.Forms.PictureBox();
            this.timer_DisplayPicture = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_DisplayTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Display)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox_SelectScreen
            // 
            this.comboBox_SelectScreen.FormattingEnabled = true;
            this.comboBox_SelectScreen.Location = new System.Drawing.Point(15, 118);
            this.comboBox_SelectScreen.Name = "comboBox_SelectScreen";
            this.comboBox_SelectScreen.Size = new System.Drawing.Size(121, 21);
            this.comboBox_SelectScreen.TabIndex = 0;
            // 
            // label_SelectScreen
            // 
            this.label_SelectScreen.AutoSize = true;
            this.label_SelectScreen.Location = new System.Drawing.Point(12, 102);
            this.label_SelectScreen.Name = "label_SelectScreen";
            this.label_SelectScreen.Size = new System.Drawing.Size(77, 13);
            this.label_SelectScreen.TabIndex = 1;
            this.label_SelectScreen.Text = "Select Screen:";
            // 
            // button_Exit
            // 
            this.button_Exit.Location = new System.Drawing.Point(15, 244);
            this.button_Exit.Name = "button_Exit";
            this.button_Exit.Size = new System.Drawing.Size(75, 23);
            this.button_Exit.TabIndex = 2;
            this.button_Exit.Text = "Exit";
            this.button_Exit.UseVisualStyleBackColor = true;
            this.button_Exit.Click += new System.EventHandler(this.button_Exit_Click);
            // 
            // button_Browse
            // 
            this.button_Browse.Location = new System.Drawing.Point(15, 12);
            this.button_Browse.Name = "button_Browse";
            this.button_Browse.Size = new System.Drawing.Size(75, 23);
            this.button_Browse.TabIndex = 3;
            this.button_Browse.Text = "Browse";
            this.button_Browse.UseVisualStyleBackColor = true;
            this.button_Browse.Click += new System.EventHandler(this.button_Browse_Click);
            // 
            // textBox_FileLocation
            // 
            this.textBox_FileLocation.Location = new System.Drawing.Point(15, 66);
            this.textBox_FileLocation.Name = "textBox_FileLocation";
            this.textBox_FileLocation.ReadOnly = true;
            this.textBox_FileLocation.Size = new System.Drawing.Size(370, 20);
            this.textBox_FileLocation.TabIndex = 4;
            // 
            // label_Location
            // 
            this.label_Location.AutoSize = true;
            this.label_Location.Location = new System.Drawing.Point(12, 50);
            this.label_Location.Name = "label_Location";
            this.label_Location.Size = new System.Drawing.Size(67, 13);
            this.label_Location.TabIndex = 5;
            this.label_Location.Text = "File Location";
            // 
            // label_DisplayTime
            // 
            this.label_DisplayTime.AutoSize = true;
            this.label_DisplayTime.Location = new System.Drawing.Point(12, 161);
            this.label_DisplayTime.Name = "label_DisplayTime";
            this.label_DisplayTime.Size = new System.Drawing.Size(137, 13);
            this.label_DisplayTime.TabIndex = 6;
            this.label_DisplayTime.Text = "Choose Display Time (Sec):";
            // 
            // numericUpDown_DisplayTime
            // 
            this.numericUpDown_DisplayTime.Location = new System.Drawing.Point(15, 177);
            this.numericUpDown_DisplayTime.Name = "numericUpDown_DisplayTime";
            this.numericUpDown_DisplayTime.Size = new System.Drawing.Size(118, 20);
            this.numericUpDown_DisplayTime.TabIndex = 7;
            this.numericUpDown_DisplayTime.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // button_Show
            // 
            this.button_Show.Enabled = false;
            this.button_Show.Location = new System.Drawing.Point(15, 203);
            this.button_Show.Name = "button_Show";
            this.button_Show.Size = new System.Drawing.Size(75, 23);
            this.button_Show.TabIndex = 8;
            this.button_Show.Text = "Show Me!";
            this.button_Show.UseVisualStyleBackColor = true;
            this.button_Show.Click += new System.EventHandler(this.button_Show_Click);
            // 
            // pictureBox_Display
            // 
            this.pictureBox_Display.Location = new System.Drawing.Point(155, 102);
            this.pictureBox_Display.Name = "pictureBox_Display";
            this.pictureBox_Display.Padding = new System.Windows.Forms.Padding(15);
            this.pictureBox_Display.Size = new System.Drawing.Size(230, 165);
            this.pictureBox_Display.TabIndex = 9;
            this.pictureBox_Display.TabStop = false;
            // 
            // timer_DisplayPicture
            // 
            this.timer_DisplayPicture.Enabled = true;
            this.timer_DisplayPicture.Interval = 500;
            // 
            // Form_DisplayPicture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(404, 288);
            this.Controls.Add(this.pictureBox_Display);
            this.Controls.Add(this.button_Show);
            this.Controls.Add(this.numericUpDown_DisplayTime);
            this.Controls.Add(this.label_DisplayTime);
            this.Controls.Add(this.label_Location);
            this.Controls.Add(this.textBox_FileLocation);
            this.Controls.Add(this.button_Browse);
            this.Controls.Add(this.button_Exit);
            this.Controls.Add(this.label_SelectScreen);
            this.Controls.Add(this.comboBox_SelectScreen);
            this.Name = "Form_DisplayPicture";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ronen\'s Display-Picture";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_DisplayTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Display)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_SelectScreen;
        private System.Windows.Forms.Label label_SelectScreen;
        private System.Windows.Forms.Button button_Exit;
        private System.Windows.Forms.Button button_Browse;
        private System.Windows.Forms.FolderBrowserDialog folderDialogBox;
        private System.Windows.Forms.TextBox textBox_FileLocation;
        private System.Windows.Forms.Label label_Location;
        private System.Windows.Forms.Label label_DisplayTime;
        private System.Windows.Forms.NumericUpDown numericUpDown_DisplayTime;
        private System.Windows.Forms.Button button_Show;
        private System.Windows.Forms.PictureBox pictureBox_Display;
        private System.Windows.Forms.Timer timer_DisplayPicture;
    }
}


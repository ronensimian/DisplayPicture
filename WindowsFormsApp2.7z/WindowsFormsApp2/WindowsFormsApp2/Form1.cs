﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form_DisplayPicture : Form
    {
        public Form_DisplayPicture()
        {
            InitializeComponent();

            // Initialize screen select
            comboBox_SelectScreen.Items.Clear();
            Screen[] ScreenArray = Screen.AllScreens;
            for (int i = 0; i < ScreenArray.Length; i++)
            {
                comboBox_SelectScreen.Items.Add("Screen " + Convert.ToString(i + 1));
            }
            if (comboBox_SelectScreen.Items.Count > 0)
            {
                comboBox_SelectScreen.SelectedIndex = 0;
            }
        }


        private void button_Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPG Files|*.jpg|PNG Files|*.png|BMP Files|*.bmp" };
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBox_FileLocation.Text = ofd.FileName;
                button_Show.Enabled = true;
            }

        }

        private void button_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_Show_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve the image.
                Bitmap img = new Bitmap(textBox_FileLocation.Text);

                // Display image in pictureBox.
                pictureBox_Display.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBox_Display.Image = img;

                // Display image in a new Form.
                Form imageForm = new Form();
                imageForm.BackgroundImage = img;
                imageForm.BackgroundImageLayout = ImageLayout.Stretch;
                imageForm.WindowState = FormWindowState.Maximized;
                imageForm.ControlBox = false;
                imageForm.MaximizeBox = false;
                // some fail-safe commands
                imageForm.ShowIcon = false;
                imageForm.ShowInTaskbar = false;
                imageForm.TopMost = true;
                imageForm.MinimizeBox = false;
                imageForm.Size = new Size(500, 500);
                imageForm.Location = new Point(0, 0);

                // Display in selected screen.
                imageForm.StartPosition = FormStartPosition.Manual;
                Screen scr = Screen.AllScreens[comboBox_SelectScreen.SelectedIndex];
                imageForm.SetBounds(scr.Bounds.X, scr.Bounds.Y, scr.Bounds.Width, scr.Bounds.Height);
                imageForm.Show();

                // Show picture for the chosen value of seconds
                Thread.Sleep(1000 * (int)numericUpDown_DisplayTime.Value);
                imageForm.Close();

            }
            catch (ArgumentException)
            {
                MessageBox.Show("Error, Please check File location");
            }
        }


    }
}
